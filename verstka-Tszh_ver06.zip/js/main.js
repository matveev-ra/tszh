
$(document).ready(function () {


$(".Hdblock").click(function() {
    var el = $(this).parent().find(".hidden");

    el.toggleClass( "active" );

    el.each(function(){

    if(el.hasClass('active')) {
        $(this).parent().find('.updown').addClass('up');
        $(this).parent().find('.updown').removeClass('down');
            el.fadeIn();
            
        } else {
            $(this).parent().find('.updown').removeClass('up');
            $(this).parent().find('.updown').addClass('down');
            el.fadeOut();
        }
        return false;
     });
    });



    $(".Btnlogin").click(function() {
        var el = $(this).parent().parent().find(".LoginForma");
    
        el.toggleClass( "active" );
    
        if(el.hasClass('active')) {
            $(this).addClass('up');
                // el.fadeIn();
                
            } else {
                
                $(this).removeClass('up');
                // el.fadeOut();
            }
            return false;
        });
  
      
            // var width = $(window).width(); // Ширина экрана
            // if(width <= 540){
            //  $('.innnerFoto').addClass('owl-carousel');
            // }
         


        $('.owl-carousel').owlCarousel({
            loop:true,
            margin:10,
            nav:true,
            items:1,
            dots:false,
            autoHeight:true
            // navClass: ['owl-prev1','owl-next1'],
            // navText: ['<span class="icon owlarrow"></span>','<span class="icon owlarrow"></span>'],
            // responsiveClass:true,
            // responsive:{
            //     320:{
            //         nav:false,
            //         dots:true
            //     },
            //     768:{
            //         nav:true,
            //         items:1,
            //         dots:false
            //     }
            // }
            
        });
        

});//$(document).ready(function ()